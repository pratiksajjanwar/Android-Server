package com.example.arahan.androidserver;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arahan.androidserver.Adapters.RecyclerAdapterFileList;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Map;

import fi.iki.elonen.NanoHTTPD;

public class FileServerActivity extends AppCompatActivity {

    RecyclerView fileListRv;
    RecyclerView.LayoutManager rvLayoutManager;
    RecyclerAdapterFileList rvAdapter;
    private static final int PORT = 8080;
    private MyHTTPD server;
    private Handler handler = new Handler();
    TextView ipAddressTv;
    ArrayList<File> fileArrayList;
    File[] files;
    Toolbar t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_server);
        t = findViewById(R.id.toolbar);
        setSupportActionBar(t);
        t.setTitle("Server");
        fileArrayList = new ArrayList<>();

        ipAddressTv = findViewById(R.id.tv_ip_address);
        fileListRv = findViewById(R.id.rv_files_list);
        rvLayoutManager = new LinearLayoutManager(FileServerActivity.this,
                LinearLayoutManager.VERTICAL,false);
        //rvAdapter = new RecyclerAdapterFileList();
        fileListRv.setLayoutManager(rvLayoutManager);
        //fileListRv.setAdapter(rvAdapter);

        //retrieving data from folder
        fileArrayList = new ArrayList<>();
        files = retrieveFiles();
        for(int i = 0;i < files.length;i++){
            fileArrayList.add(files[i]);
        }
        rvAdapter = new RecyclerAdapterFileList(fileArrayList,FileServerActivity.this);
        fileListRv.setAdapter(rvAdapter);

        @SuppressLint("WifiManagerLeak") WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
        int ipAddress = wifiManager.getConnectionInfo().getIpAddress();
        final String formatedIpAddress = String.format("%d.%d.%d.%d", (ipAddress & 0xff), (ipAddress >> 8 & 0xff),
                (ipAddress >> 16 & 0xff), (ipAddress >> 24 & 0xff));
        ipAddressTv.setText("http://" + formatedIpAddress + ":" + PORT+"/storage/emulated/0/AndroidServer/");
        //IP = formatedIpAddress;
        //publicIP = formatedIpAddress;
    }

    public File[] retrieveFiles(){
        String path = Environment.getExternalStorageDirectory().toString()+"/AndroidServer";
        File directory = new File(path);
        File[] files = directory.listFiles();
        Log.d("File",files.toString());
        return files;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_file_server,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.it_add_file:
                Intent intent = new Intent();
                intent.setType("*/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent,1);
                break;
            case R.id.it_start:
                //starting the server
                t.setTitle("Server Running");
                try {
                    server = new MyHTTPD();
                }catch (IOException e){
                    e.printStackTrace();
                }
                break;
            case R.id.it_pause:
                t.setTitle("Server Stop");
                if (server != null) {
                    server.stop();
                }
                break;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 1:
                copyFile(data);
                break;
        }
    }

    public void copyFile(Intent data){
        InputStream in = null;
        OutputStream out = null;
        String inputFilePath = data.getData().getPath();
        File file = new File(inputFilePath);
        Log.e("File ",inputFilePath);
        inputFilePath.substring(15);
        Log.e("File ",inputFilePath.substring(15));
        try{
            in = new FileInputStream(Environment.getExternalStorageDirectory().toString()+
                    inputFilePath.substring(15));
            out = new FileOutputStream(Environment.getExternalStorageDirectory().toString()+
                    "/AndroidServer/"+file.getName());
            byte[] buffer = new byte[1024];
            int read;
            while((read = in.read(buffer)) != -1){
                out.write(buffer,0,read);
            }
            in.close();
            Toast.makeText(getApplicationContext(),inputFilePath,Toast.LENGTH_SHORT).show();
            //files[files.length] = file.getName().toString();
            files = retrieveFiles();
            fileArrayList.clear();
            for(int i = 0;i < files.length;i++){
                fileArrayList.add(files[i]);
            }
            rvAdapter.setItems(fileArrayList);
            rvAdapter.notifyDataSetChanged();
        }catch (FileNotFoundException e){
            Log.e("File Select",e.getLocalizedMessage());
        } catch (IOException e) {
            Log.e("File Select",e.getLocalizedMessage());
        }
    }


    //class for NanoHttpd
    private class MyHTTPD extends NanoHTTPD {

        public MyHTTPD() throws IOException{
            super(PORT);
            start();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(),"Running ",Toast.LENGTH_LONG).show();
                }
            });
        }

        @Override
        public Response serve(String uri, Method method, Map<String, String> headers, Map<String,
                String> parms, Map<String, String> files) {
            File rootDir = Environment.getExternalStorageDirectory();
            File[] filesList = rootDir.listFiles();
            String filepath = "";

            filepath = uri.trim();
            File newFile = new File(filepath);
            if(newFile.isFile()){
                FileInputStream fileInputStream= null;
                try {
                    fileInputStream = new FileInputStream(new File(filepath));
                }catch (FileNotFoundException e){
                    final String err = e.getLocalizedMessage();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),err,Toast.LENGTH_LONG).show();
                        }
                    });
                }
                return  new NanoHTTPD.Response(Response.Status.OK , "text/*|application/pdf|image/*|audio/mpeg",
                        fileInputStream);
            }
            else {
                filesList = new File(filepath).listFiles();
                System.out.println(filepath);
                String answer = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">" +
                        "<title>sdcard - TECNO P5 - WiFi File Transfer Pro</title>";
                for (File detailsOfFile : filesList) {
                    if (detailsOfFile.isFile()) {
                        answer += "<a href=\"" + detailsOfFile.getAbsoluteFile()
                                + "\" alt = \"\" download onclick = >" + detailsOfFile.getName()
                                + "File</a><br>";
                    } else {
                        answer += "<a href=\"" + detailsOfFile.getAbsoluteFile()
                                + "\" alt = \"\" onclick = >" + detailsOfFile.getName()
                                + "Directory</a><br>";
                    }
                }
                answer += "</head></html>";
                return new NanoHTTPD.Response(answer + uri);
            }
        }
    }
}