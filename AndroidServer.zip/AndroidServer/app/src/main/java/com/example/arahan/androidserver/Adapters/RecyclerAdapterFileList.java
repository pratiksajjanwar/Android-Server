package com.example.arahan.androidserver.Adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arahan.androidserver.R;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by arahan on 30/5/18.
 */

public class RecyclerAdapterFileList extends RecyclerView.Adapter<RecyclerAdapterFileList.ViewHolder>{

    ArrayList<File> fileArrayList;
    Context context;
    public RecyclerAdapterFileList(ArrayList<File> fileArrayList, Context context){
        this.fileArrayList = fileArrayList;
        this.context = context;
    }

    @Override
    public RecyclerAdapterFileList.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_file_list_item,
                parent,false);
        ViewHolder v = new ViewHolder(view);
        return v;
    }

    @Override
    public void onBindViewHolder(RecyclerAdapterFileList.ViewHolder holder, final int position) {
        holder.fileName.setText(fileArrayList.get(position).getName().toString());
        holder.customFileListItemLl.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                LayoutInflater layoutInflater = LayoutInflater.from(context);
                View view1 = layoutInflater.inflate(R.layout.delete_file,null);
                AlertDialog.Builder aBuilder = new AlertDialog.Builder(context);
                aBuilder.setView(view1);
                TextView deleteTv = view1.findViewById(R.id.tv_delete_file);
                if (fileArrayList.get(position).isFile()){
                    deleteTv.setText("Delete File: "+fileArrayList.get(position).getName());
                }
                else {
                    deleteTv.setText("Delete Directory: "+fileArrayList.get(position).getName());
                }
                aBuilder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Boolean val = fileArrayList.get(position).delete();
                        Toast.makeText(context, "File Deleted", Toast.LENGTH_SHORT).show();
                        dialogInterface.dismiss();
                        fileArrayList.remove(position);
                        notifyDataSetChanged();
                    }
                });
                aBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                aBuilder.setCancelable(false);
                AlertDialog alertDialog = aBuilder.create();
                alertDialog.show();
                return true;
            }
        });

    }

    public void setItems(ArrayList<File> fileArrayList){
        this.fileArrayList = fileArrayList;
    }

    @Override
    public int getItemCount() {
        return fileArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView fileName;
        LinearLayout customFileListItemLl;
        public ViewHolder(View itemView) {
            super(itemView);
            fileName = itemView.findViewById(R.id.tv_file_name);
            customFileListItemLl = itemView.findViewById(R.id.ll_custom_file_list_item);
        }
    }
}
