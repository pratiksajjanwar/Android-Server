package com.example.arahan.androidserver.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.arahan.androidserver.Data.User;
import com.example.arahan.androidserver.R;

import java.util.ArrayList;

/**
 * Created by arahan on 2/6/18.
 */

public class RecyclerAdapterUserList extends RecyclerView.Adapter<RecyclerAdapterUserList.ViewHolder>{

    ArrayList<User> userList;
    Context context;

    public RecyclerAdapterUserList(ArrayList<User> userList, Context context){
           this.userList = userList;
           this.context = context;
    }

    public void setItems(ArrayList<User> userList){
        //this.userList.clear();
        this.userList = userList;
    }

    @Override
    public RecyclerAdapterUserList.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_user_list_item,
                parent,false);
        RecyclerAdapterUserList.ViewHolder v = new RecyclerAdapterUserList.ViewHolder(view);
        return v;
    }

    @Override
    public void onBindViewHolder(RecyclerAdapterUserList.ViewHolder holder, int position) {
        holder.userName.setText(userList.get(position).getName());
        holder.score.setText(String.valueOf(userList.get(position).getScore()));
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView userName,score;

        public ViewHolder(View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.tv_user_name);
            score = itemView.findViewById(R.id.tv_score);
        }
    }
}
