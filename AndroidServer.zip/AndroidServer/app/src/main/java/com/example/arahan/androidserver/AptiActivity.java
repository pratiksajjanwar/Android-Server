package com.example.arahan.androidserver;

import android.annotation.SuppressLint;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arahan.androidserver.Adapters.RecyclerAdapterUserList;
import com.example.arahan.androidserver.Data.User;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import fi.iki.elonen.NanoHTTPD;

public class AptiActivity extends AppCompatActivity {

    RecyclerView userListRv;
    RecyclerView.LayoutManager rvLayoutManager;
    RecyclerAdapterUserList rvAdapter;
    private static final int PORT = 8080;
    private MyHTTPD server;
    private Handler handler = new Handler();
    TextView ipAddressTv;
    Toolbar t;
    ArrayList<User> userList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apti);
        t = findViewById(R.id.toolbar);
        setSupportActionBar(t);
        t.setTitle("Server");

        userList = new ArrayList<>();
        ipAddressTv = findViewById(R.id.tv_ip_address);
        userListRv = findViewById(R.id.rv_files_list);
        rvLayoutManager = new LinearLayoutManager(AptiActivity.this,
                LinearLayoutManager.VERTICAL,false);
        //rvAdapter = new RecyclerAdapterFileList();
        userListRv.setLayoutManager(rvLayoutManager);
        rvAdapter = new RecyclerAdapterUserList(userList,AptiActivity.this);
        userListRv.setAdapter(rvAdapter);

        @SuppressLint("WifiManagerLeak") WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
        int ipAddress = wifiManager.getConnectionInfo().getIpAddress();
        final String formatedIpAddress = String.format("%d.%d.%d.%d", (ipAddress & 0xff), (ipAddress >> 8 & 0xff),
                (ipAddress >> 16 & 0xff), (ipAddress >> 24 & 0xff));
        ipAddressTv.setText("http://" + formatedIpAddress + ":" + PORT);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_file_server,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.it_start:
                //starting the server
                t.setTitle("Server Running");
                try {
                    server = new MyHTTPD();
                }catch (IOException e){
                    e.printStackTrace();
                }
                break;
            case R.id.it_pause:
                t.setTitle("Server Stop");
                if (server != null) {
                    server.stop();
                }
                break;
        }
        return true;
    }

    //class for NanoHttpd
    private class MyHTTPD extends NanoHTTPD {

        public MyHTTPD() throws IOException{
            super(PORT);
            start();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(),"Running ",Toast.LENGTH_LONG).show();
                }
            });
        }

        @Override
        public Response serve(String uri, Method method, Map<String, String> headers, Map<String,
                String> parms, Map<String, String> files) {

            File rootDir = new File(Environment.getExternalStorageDirectory()+"/Website/Images");
            File[] files1 = rootDir.listFiles();
            Log.e("URI",uri);
            String answer=null;
            if (uri.contains("correct")){
                int val = Integer.parseInt(uri.substring(8,9));
                String name = uri.substring(9);
                int score = val-1;
                answer="<html><body onload=\"check()\"><div id = \"after_submit\"><p id = \"number_correct\"" +
                        "></p><h3>Hey, "+name+"</h3><p id = \"message\">You Got "+val+"</p></div>" +
                        "<style>" +
                        "#after_submit {" +
                        "background: #ff5459;" +
                        "padding: 10px 20px 10px 20px;" +
                        "width: 400px;" +
                        "border-radius: 20px;" +
                        "float: left;" +
                        "margin-left: 20px;" +
                        "font-size: 30px;" +
                        "}"+
                        "#picture {" +
                        "width: 375px;" +
                        "height: 245px;" +
                        "}" +
                        "body {" +
                        "font-family: 'Lato', sans-serif;" +
                        "}" +
                        "#quiz {" +
                        "margin-left: 10px;" +
                        "background: #d2def2;" +
                        "padding: 10px 20px 10px 20px;" +
                        "width: 400px;" +
                        "border-radius: 20px;" +
                        "float: left;" +
                        "}" +
                        "input {" +
                        "margin-bottom: 20px;" +
                        "display: block;" +
                        "}" +
                        "#textbox {" +
                        "height: 25px;" +
                        "font-size: 16px;" +
                        "border-radius: 5px;" +
                        "border: none;" +
                        "padding-left: 5px;" +
                        "}" +
                        "#button {" +
                        "background: green;" +
                        "border: none;" +
                        "border-radius: 5px;" +
                        "padding: 10px;" +
                        "color: white;" +
                        "font-size: 16px;" +
                        "transition-duration: .5s;" +
                        "margin-top: 15px;" +
                        "}" +
                        "#button:hover {" +
                        "background: white;" +
                        "border: 1px solid green;" +
                        "color: black;" +
                        "cursor: pointer;" +
                        "}" +
                        "#picture {" +
                        "width: 375px;" +
                        "height: 245px;" +
                        "}" +
                        "#mc {" +
                        "display: inline;" +
                        "} " +
                        "</style>" +
                        "<script>" +
                        "function check(){" +
                        "var messages = [\"Great job!\", \"That's just okay\", \"You really need to do better\"];" +
                        "document.getElementById(\"message\").innerHTML = messages["+score+"];" +
                        "}" +
                        "</script" +
                        "</body></html>";
                        userList.add(new User(name,val));
                        rvAdapter.setItems(userList);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                rvAdapter.notifyDataSetChanged();
                            }
                        });
                        Log.e("User List",userList.toString());
            }
            else {
                answer = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; " +
                        "charset=utf-8\">" + "<link href=\"https://fonts.googleapis.com/css?family=Lato\"" +
                        " rel=\"stylesheet\"><title>sdcard - TECNO P5 - WiFi File Transfer Pro</title>" +
                        "<script>function check(){" +
                        "var question1 = document.quiz.question1.value;" +
                        "var question2 = document.quiz.question2.value;" +
                        "var question3 = document.quiz.question3.value;" +
                        "var username = document.quiz.username.value;" +
                        "var correct = 0;" +
                        "if (question1 == \"Providence\") {" +
                        "correct++;" +
                        "}" +
                        "if (question2 == \"Hartford\") {" +
                        "correct++;" +
                        "}" +
                        "if (question3 == \"Albany\") {" +
                        "correct++;" +
                        "}" +
                        "var score;" +
                        "if (correct == 0) {" +
                        "score = 2;" +
                        "}" +
                        "if (correct > 0 && correct < 3) {" +
                        "score = 1;" +
                        "}" +
                        "if (correct == 3) {" +
                        "score = 0;" +
                        "}" +
                        "window.open(\"correct\"+correct+username);}" +
                        "</script>" +
                        "<style>" +
                        "body {" +
                        "font-family: 'Lato', sans-serif;" +
                        "}" +
                        "#quiz {" +
                        "margin-left: 10px;" +
                        "background: #d2def2;" +
                        "padding: 10px 20px 10px 20px;" +
                        "width: 400px;" +
                        "border-radius: 20px;" +
                        "float: left;" +
                        "}" +
                        "input {" +
                        "margin-bottom: 20px;" +
                        "display: block;" +
                        "}" +
                        "#textbox {" +
                        "height: 25px;" +
                        "font-size: 16px;" +
                        "border-radius: 5px;" +
                        "border: none;" +
                        "padding-left: 5px;" +
                        "}" +
                        "#button {" +
                        "background: green;" +
                        "border: none;" +
                        "border-radius: 5px;" +
                        "padding: 10px;" +
                        "color: white;" +
                        "font-size: 16px;" +
                        "transition-duration: .5s;" +
                        "margin-top: 15px;" +
                        "}" +
                        "#button:hover {" +
                        "background: white;" +
                        "border: 1px solid green;" +
                        "color: black;" +
                        "cursor: pointer;" +
                        "}" +
                        "#picture {" +
                        "width: 375px;" +
                        "height: 245px;" +
                        "}" +
                        "#mc {" +
                        "display: inline;" +
                        "} " +
                        "</style></head><body><h1>This is best quiz on the internet!</h1>" +
                        "<form id = \"quiz\" name = \"quiz\"><p class = \"questions\">Enter your Name</p>" +
                        "<br><input id = \"textbox\" " +
                        "type = \"text\" name = \"username\"><p class = \"questions\">What is the capital of Rhode Island?" +
                        "</p><input id = \"textbox\" type = \"text\" name = \"question1\"><p class = \"" +
                        "questions\">What is the capital of Connecticut?</p><input type = \"radio\" id =" +
                        "\"mc\" name = \"question2\" value = \"Hartford\"> Hartford<br><input type = " +
                        "\"radio\" id = \"mc\" name = \"question2\" value = \"Heartford\"> Heartford<br>" +
                        "<p class = \"questions\">What is the capital of New York?</p><input type = " +
                        "\"radio\" id = \"mc\" name = \"question3\" value = \"Albany\"> Albany<br>" +
                        "<input type = \"radio\" id = \"mc\" name = \"question3\" value = \"All Benny's\">" +
                        "All Benny's<br><input id = \"button\" type = \"button\" value = \"I'm finished!\"" +
                        "onclick = \"check();\"></form></html>";
                    }
            return new NanoHTTPD.Response(answer + uri);
            }
        }
    }