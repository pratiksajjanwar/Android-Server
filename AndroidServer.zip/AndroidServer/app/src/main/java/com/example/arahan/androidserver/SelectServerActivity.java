package com.example.arahan.androidserver;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.File;

public class SelectServerActivity extends AppCompatActivity {

    TextView serverTv,aptiTestTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_server);

        serverTv = findViewById(R.id.tv_server);
        aptiTestTv = findViewById(R.id.tv_apti_test);

        serverTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectServerActivity.this,
                        FileServerActivity.class);
                startActivity(intent);
            }
        });
        aptiTestTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SelectServerActivity.this,
                        AptiActivity.class);
                startActivity(intent);
            }
        });

        File folder = new File(Environment.getExternalStorageDirectory()+
                "/AndroidServer");
        if (!folder.exists()){
            if (!folder.mkdir()){
                Log.d("Folder: ","Cannot create Folder");
            }
        }
    }
}
