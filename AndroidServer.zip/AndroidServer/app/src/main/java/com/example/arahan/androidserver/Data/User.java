package com.example.arahan.androidserver.Data;

/**
 * Created by arahan on 2/6/18.
 */

public class User {

    String Name;
    int score;

    public User(String name, int score) {
        Name = name;
        this.score = score;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
