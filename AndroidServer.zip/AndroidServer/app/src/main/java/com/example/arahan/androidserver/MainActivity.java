package com.example.arahan.androidserver;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;

import fi.iki.elonen.NanoHTTPD;

public class MainActivity extends Activity {
    private static final int PORT = 8080;
    private MyHTTPD server;
    private String IP = "";
    private Handler handler = new Handler();
    EditText textEt;
    Button sendBt;
    String publicIP = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textEt = findViewById(R.id.et_text);
        sendBt = findViewById(R.id.bt_send);

        sendBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    server = new MyHTTPD();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        TextView textIpaddr = findViewById(R.id.ipaddr);
        @SuppressLint("WifiManagerLeak") WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
        int ipAddress = wifiManager.getConnectionInfo().getIpAddress();
        final String formatedIpAddress = String.format("%d.%d.%d.%d", (ipAddress & 0xff), (ipAddress >> 8 & 0xff),
                (ipAddress >> 16 & 0xff), (ipAddress >> 24 & 0xff));
        textIpaddr.setText("Please access! http://" + formatedIpAddress + ":" + PORT);
        IP = formatedIpAddress;
        publicIP = formatedIpAddress;
    }

    @Override
    protected void onPause() {
        super.onPause();
        /*if (server != null)
            server.stop();*/
    }

    private class MyHTTPD extends NanoHTTPD {

        public MyHTTPD() throws IOException{
            super(PORT);
            start();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(getApplicationContext(),"Running ",Toast.LENGTH_LONG).show();
                }
            });
        }

        @Override
        public Response serve(String uri, Method method, Map<String, String> headers, Map<String,
                String> parms, Map<String, String> files) {
            File rootDir = Environment.getExternalStorageDirectory();
            File[] filesList = rootDir.listFiles();
            String filepath = "";

            filepath = uri.trim();
            File newFile = new File(filepath);
            if(newFile.isFile()){
                FileInputStream fileInputStream= null;
                try {
                    fileInputStream = new FileInputStream(new File(filepath));
                }catch (FileNotFoundException e){
                    final String err = e.getLocalizedMessage();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),err,Toast.LENGTH_LONG).show();
                        }
                    });
                }
                return  new NanoHTTPD.Response(Response.Status.OK , "text/*|application/pdf|image/*|audio/mpeg",
                        fileInputStream);
            }
            else {
                filesList = new File(filepath).listFiles();
                System.out.println(filepath);
                String answer = "<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">" +
                        "<title>sdcard - TECNO P5 - WiFi File Transfer Pro</title>";
                for (File detailsOfFile : filesList) {
                    if (detailsOfFile.isFile()) {
                        answer += "<a href=\"" + detailsOfFile.getAbsoluteFile()
                                + "\" alt = \"\" download onclick = >" + detailsOfFile.getName()
                                + "File</a><br>";
                    } else {
                        answer += "<a href=\"" + detailsOfFile.getAbsoluteFile()
                                + "\" alt = \"\" onclick = >" + detailsOfFile.getName()
                                + "Directory</a><br>";
                    }
                }
                answer += "</head></html>";
                return new NanoHTTPD.Response(answer + uri);
            }
        }

        public void download(){

        }


    }
}

/*@Override
        public Response serve(String uri, Method method, Map<String, String> headers,
                              Map<String, String> parms, Map<String, String> files) {
            String answer = "";
            try {
                FileReader index = new FileReader(Environment.getExternalStorageDirectory()
                        + "/www/index.php");
                BufferedReader reader = new BufferedReader(index);
                String line = "";
                while ((line = reader.readLine())!=null){
                    answer += line;
                }
                reader.close();
            }catch (Exception e){
                Log.e("",e.getLocalizedMessage());
            }
            Log.e("answer",answer);
            return  new NanoHTTPD.Response(answer+Environment.getExternalStorageDirectory()
                    + "/www/index.php");
        }
*/
/*@Override
        public Response serve(String uri, Method method, Map<String, String> headers,
                              Map<String, String> parms, Map<String, String> files) {
            FileInputStream fileInputStream= null;
            try {
                fileInputStream = new FileInputStream(Environment.getExternalStorageDirectory()
                        +"/DCIM/");
            }catch (FileNotFoundException e){
                final String err = e.getLocalizedMessage();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),err,Toast.LENGTH_LONG).show();
                    }
                });
            }
            return  new NanoHTTPD.Response(Response.Status.OK , "application/vnd.google-apps.folder",fileInputStream);
        }*/
//audio/mpeg +"/forever.mp3"

/*public Response serve(String uri, Method method, Map<String, String> headers,
                              Map<String, String> parms, Map<String, String> files) {
            FileInputStream fileInputStream= null;
            try {
                fileInputStream = new FileInputStream(Environment.getExternalStorageDirectory()
                +"/forever.mp3");
            }catch (FileNotFoundException e){
                final String err = e.getLocalizedMessage();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),err,Toast.LENGTH_LONG).show();
                    }
                });
            }
            return  new NanoHTTPD.Response(Response.Status.OK , "audio/mpeg",fileInputStream);
        }*/
/*String msg = "<html><body bgcolor=#000000><center><font color=white><h1>Welcome to NanoHTTPD</h1>" +
                    "<h2>Hello "+textEt.getText()+"</h2><br><br>" +
                    "<p>Hosting Servers on Android Phones Using Nano-HTTPD and MQTT Protocol</p>"+
                    "<br><br>"+
                    "<h3>Project Guide: Prof. V.V. Bagade Sir</h3></font></center>\n";
            return  new NanoHTTPD.Response(msg + "</body></html>\n");*/